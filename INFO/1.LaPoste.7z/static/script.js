async function typeWriterEffect(text, element, delay = 25) {
  element.textContent = ''; // очистить перед началом
  for (let i = 0; i < text.length; i++) {
    element.textContent += text.charAt(i);
    await new Promise(resolve => setTimeout(resolve, delay));
  }
}

async function showEventsSequentially(events) {
  const container = document.getElementById('events');
  container.innerHTML = '';

  for (const event of events) {
    const p = document.createElement('p');
    p.className = 'event-item';

    const spinner = document.createElement('span');
    spinner.className = 'spinner';
    p.appendChild(spinner);

    const textSpan = document.createElement('span');
    p.appendChild(textSpan);

    container.appendChild(p);

    // Печатаем французский текст по символам
    await typeWriterEffect(`${event.date} — ${event.label}`, textSpan);

    // Затем печатаем перевод тоже с эффектом машинки
    if (event.label_ru) {
      const translationSpan = document.createElement('span');
      translationSpan.className = 'translation';
      p.appendChild(translationSpan); // вставляем до эффекта, чтобы он был на месте
      await typeWriterEffect(` [${event.label_ru}]`, translationSpan);
    }
  }
}



document.addEventListener('DOMContentLoaded', () => {
  const eventsData = document.getElementById('events-data');
  if (eventsData) {
    const events = JSON.parse(eventsData.textContent);
    if (events.length > 0) {
      showEventsSequentially(events);
    } else {
      document.getElementById('events').textContent = 'Нет событий для отображения.';
    }
  }
});
